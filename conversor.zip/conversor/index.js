function convert() {
  // Taxa de câmbio 
  const exchangeRate = 0.18;
  const exchange = 0.16;
  const amount = parseFloat(document.getElementById('amount').value);

  // Verifica se o valor é um número e é maior que 0
  if (isNaN(amount) || amount <= 0) {
      document.getElementById('result,result2').innerText = 'Por favor, insira um valor válido.';
      return;
      
  }

  const dollars = amount * exchangeRate;
  const euro = amount * exchange;

  document.getElementById('result').innerText = `Valor em Dólares: $${dollars.toFixed(2) }`;
  document.getElementById('result2').innerText = `Valor em Euro: $${euro.toFixed(2)}`;

}
